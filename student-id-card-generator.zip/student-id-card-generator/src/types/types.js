// src/types/types.js
export const CLASS_OPTIONS = [
    "Class I", "Class II", "Class III", "Class IV", "Class V",
    "Class VI", "Class VII", "Class VIII", "Class IX", "Class X",
    "Class XI Science", "Class XI Commerce", "Class XI Arts",
    "Class XII Science", "Class XII Commerce", "Class XII Arts"
  ];
  
  export const BUS_ROUTES = [
    "Route 1: North Campus",
    "Route 2: South Campus",
    "Route 3: East Campus", 
    "Route 4: West Campus",
    "Route 5: Central Area",
    "Route 6: Suburban Line",
    "Route 7: Express Line",
    "Not Applicable"
  ];
  
  export const ALLERGY_OPTIONS = [
    "Peanuts", 
    "Tree Nuts", 
    "Milk", 
    "Eggs", 
    "Wheat", 
    "Soy", 
    "Fish", 
    "Shellfish",
    "Gluten",
    "None"
  ];
  