// src/components/TemplateSelector.jsx
import React from 'react';

const TemplateSelector = ({ 
  selectedTemplate, 
  onTemplateChange 
}) => {
  return (
    <div className="template-selector">
      <div 
        className={`template-option ${selectedTemplate === "template1" ? 'selected' : ''}`}
        onClick={() => onTemplateChange("template1")}
      >
        Template 1
      </div>
      <div 
        className={`template-option ${selectedTemplate === "template2" ? 'selected' : ''}`}
        onClick={() => onTemplateChange("template2")}
      >
        Template 2
      </div>
    </div>
  );
};

export default TemplateSelector;
