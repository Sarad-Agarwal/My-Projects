// src/components/IDCardForm.jsx (example implementation)
import React, { useState, useEffect } from 'react';
import { CLASS_OPTIONS, BUS_ROUTES, ALLERGY_OPTIONS } from '../types/types';

const IDCardForm = ({ onSubmit, initialData }) => {
  const [name, setName] = useState('');
  const [rollNumber, setRollNumber] = useState('');
  const [classDiv, setClassDiv] = useState(CLASS_OPTIONS[0]);
  const [rackNumber, setRackNumber] = useState('');
  const [busRouteNumber, setBusRouteNumber] = useState(BUS_ROUTES[0]);
  const [allergies, setAllergies] = useState([]);
  const [photo, setPhoto] = useState(null);

  useEffect(() => {
    if (initialData) {
      setName(initialData.name || '');
      setRollNumber(initialData.rollNumber || '');
      setClassDiv(initialData.classDiv || CLASS_OPTIONS[0]);
      setRackNumber(initialData.rackNumber || '');
      setBusRouteNumber(initialData.busRouteNumber || BUS_ROUTES[0]);
      setAllergies(initialData.allergies || []);
      setPhoto(initialData.photo || null);
    }
  }, [initialData]);

  const handleSubmit = (e) => {
    e.preventDefault();
    const studentData = {
      name,
      rollNumber,
      classDiv,
      rackNumber,
      busRouteNumber,
      allergies,
      photo
    };
    onSubmit(studentData);
  };

  const handlePhotoUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      setPhoto(reader.result);
    };
    reader.readAsDataURL(file);
  };

  const handleAllergyChange = (allergy) => {
    if (allergy === 'None') {
      setAllergies(['None']);
      return;
    }
    
    // Remove 'None' if it's selected and the user selects another allergy
    let updatedAllergies = [...allergies];
    if (updatedAllergies.includes('None')) {
      updatedAllergies = updatedAllergies.filter(a => a !== 'None');
    }
    
    // Toggle the allergy
    if (updatedAllergies.includes(allergy)) {
      updatedAllergies = updatedAllergies.filter(a => a !== allergy);
    } else {
      updatedAllergies.push(allergy);
    }
    
    setAllergies(updatedAllergies);
  };

  return (
    <div className="form-container">
      <h2>Student Information</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="name">Full Name</label>
          <input
            id="name"
            type="text"
            className="form-control"
            value={name}
            onChange={e => setName(e.target.value)}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="rollNumber">Roll Number</label>
          <input
            id="rollNumber"
            type="text"
            className="form-control"
            value={rollNumber}
            onChange={e => setRollNumber(e.target.value)}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="classDiv">Class</label>
          <select 
            id="classDiv" 
            className="form-control"
            value={classDiv}
            onChange={e => setClassDiv(e.target.value)}
          >
            {CLASS_OPTIONS.map(option => (
              <option key={option} value={option}>{option}</option>
            ))}
          </select>
        </div>

        <div className="form-group">
          <label htmlFor="rackNumber">Rack Number</label>
          <input
            id="rackNumber"
            type="text"
            className="form-control"
            value={rackNumber}
            onChange={e => setRackNumber(e.target.value)}
            placeholder="Optional"
          />
        </div>

        <div className="form-group">
          <label htmlFor="busRoute">Bus Route</label>
          <select 
            id="busRoute" 
            className="form-control"
            value={busRouteNumber}
            onChange={e => setBusRouteNumber(e.target.value)}
          >
            {BUS_ROUTES.map(route => (
              <option key={route} value={route}>{route}</option>
            ))}
          </select>
        </div>

        <div className="form-group">
          <label>Allergies (if any)</label>
          <div className="checkbox-group">
            {ALLERGY_OPTIONS.map(allergy => (
              <div key={allergy} className="checkbox-item">
                <input
                  type="checkbox"
                  id={`allergy-${allergy}`}
                  checked={allergies.includes(allergy)}
                  onChange={() => handleAllergyChange(allergy)}
                />
                <label htmlFor={`allergy-${allergy}`}>{allergy}</label>
              </div>
            ))}
          </div>
        </div>

        <div className="form-group">
          <label>Photo</label>
          <div className="photo-upload">
            <div className="photo-preview">
              {photo ? (
                <img src={photo} alt="Student" />
              ) : (
                <div className="upload-placeholder">No photo selected</div>
              )}
            </div>
            <input 
              type="file" 
              accept="image/*" 
              onChange={handlePhotoUpload} 
            />
          </div>
        </div>

        <div className="form-actions">
          <button type="submit" className="btn btn-primary">
            Generate ID Card
          </button>
        </div>
      </form>
    </div>
  );
};

export default IDCardForm;
