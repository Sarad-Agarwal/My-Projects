// src/components/IDCardHistory.jsx (example implementation)
import React, { useState } from 'react';
import { deleteCard } from '../utils/storage';

const IDCardHistory = ({ cards, onLoadCard, onRefresh }) => {
  const [expandedCard, setExpandedCard] = useState(null);

  const handleDelete = (cardId) => {
    if (window.confirm('Are you sure you want to delete this card?')) {
      deleteCard(cardId);
      onRefresh();
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
  };

  if (cards.length === 0) {
    return (
      <div className="history-section">
        <h2>Saved ID Cards</h2>
        <p>No saved ID cards yet. Generate a card and save it to see it here.</p>
      </div>
    );
  }

  return (
    <div className="history-section">
      <h2>Saved ID Cards</h2>
      <div className="history-list">
        {cards.map(card => (
          <div key={card.id} className="history-item">
            <div className="history-item-header">
              <h3>{card.studentData.name}</h3>
              <span>{formatDate(card.date)}</span>
            </div>
            <div className="history-item-actions">
              <button 
                className="btn btn-secondary"
                onClick={() => setExpandedCard(expandedCard === card.id ? null : card.id)}
              >
                {expandedCard === card.id ? 'Hide Details' : 'Show Details'}
              </button>
              <button 
                className="btn btn-secondary"
                onClick={() => onLoadCard(card.studentData, card.template)}
              >
                Load
              </button>
              <button 
                className="btn btn-danger"
                onClick={() => handleDelete(card.id)}
              >
                Delete
              </button>
            </div>
            
            {expandedCard === card.id && (
              <div className="history-item-details">
                <p><strong>Roll Number:</strong> {card.studentData.rollNumber}</p>
                <p><strong>Class:</strong> {card.studentData.classDiv}</p>
                <p><strong>Template:</strong> {card.template === 'template1' ? 'Template 1' : 'Template 2'}</p>
                <p><strong>Allergies:</strong> {card.studentData.allergies.length > 0 
                  ? card.studentData.allergies.join(', ') 
                  : 'None'}</p>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default IDCardHistory;
