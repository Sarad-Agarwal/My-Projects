// src/components/IDCardPreview.jsx
import React, { useRef } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import * as htmlToImage from 'html-to-image';
import { saveAs } from 'file-saver';

const IDCardPreview = ({ 
  studentData, 
  template,
  onSave 
}) => {
  const cardRef = useRef(null);
  
  const qrCodeData = JSON.stringify({
    name: studentData.name,
    rollNumber: studentData.rollNumber,
    class: studentData.classDiv,
    allergies: studentData.allergies,
    rackNumber: studentData.rackNumber,
    busRouteNumber: studentData.busRouteNumber
  });
  
  const downloadImage = () => {
    if (!cardRef.current) return;
    
    htmlToImage.toPng(cardRef.current)
      .then((dataUrl) => {
        saveAs(dataUrl, `${studentData.name.replace(/\s+/g, '_')}_ID_Card.png`);
        onSave();
      })
      .catch((error) => {
        console.error('Error generating image:', error);
        alert('Failed to generate image. Please try again.');
      });
  };
  
  const renderTemplate1 = () => (
    <div className="id-card-template-1" ref={cardRef}>
      <div className="template-1-header">
        <h2>STUDENT IDENTIFICATION CARD</h2>
      </div>
      <div className="template-1-body">
        <div className="template-1-photo">
          {studentData.photo ? (
            <img src={studentData.photo} alt={studentData.name} />
          ) : (
            <div className="upload-placeholder">No Photo</div>
          )}
        </div>
        <div className="template-1-details">
          <h3>{studentData.name}</h3>
          <p><strong>Roll Number:</strong> {studentData.rollNumber}</p>
          <p><strong>Class:</strong> {studentData.classDiv}</p>
          <p><strong>Rack Number:</strong> {studentData.rackNumber || 'N/A'}</p>
          <p><strong>Bus Route:</strong> {studentData.busRouteNumber}</p>
          <p>
            <strong>Allergies:</strong> {' '}
            {studentData.allergies.length > 0 
              ? studentData.allergies.join(', ') 
              : 'None'}
          </p>
        </div>
        <div className="template-1-qr">
          <QRCodeSVG value={qrCodeData} size={100} />
        </div>
      </div>
      <div className="template-1-footer">
        <p>This card is the property of the school and must be carried at all times.</p>
      </div>
    </div>
  );
  
  const renderTemplate2 = () => (
    <div className="id-card-template-2" ref={cardRef}>
      <div className="template-2-side-bar"></div>
      <div className="template-2-header">
        <h2>STUDENT ID CARD</h2>
      </div>
      <div className="template-2-body">
        <div className="template-2-top">
          <div className="template-2-photo">
            {studentData.photo ? (
              <img src={studentData.photo} alt={studentData.name} />
            ) : (
              <div className="upload-placeholder">No Photo</div>
            )}
          </div>
          <div className="template-2-info">
            <h3>{studentData.name}</h3>
            <div className="roll-number">{studentData.rollNumber}</div>
            <p>{studentData.classDiv}</p>
          </div>
        </div>
        
        <div className="template-2-details">
          <div className="detail-row">
            <span className="detail-label">Rack Number:</span>
            <span>{studentData.rackNumber || 'N/A'}</span>
          </div>
          <div className="detail-row">
            <span className="detail-label">Bus Route:</span>
            <span>{studentData.busRouteNumber}</span>
          </div>
          <div className="detail-row">
            <span className="detail-label">Allergies:</span>
            <span>
              {studentData.allergies.length > 0 
                ? studentData.allergies.join(', ') 
                : 'None'}
            </span>
          </div>
        </div>
        
        <div className="template-2-qr">
          <QRCodeSVG value={qrCodeData} size={100} />
        </div>
      </div>
      <div className="template-2-footer">
        <p>If found, please return to the school administration office.</p>
      </div>
    </div>
  );

  return (
    <div className="card-preview">
      {template === "template1" ? renderTemplate1() : renderTemplate2()}
      <button className="btn btn-primary" onClick={downloadImage} style={{ marginTop: '1rem' }}>
        Download as PNG
      </button>
    </div>
  );
};

export default IDCardPreview;
