// src/App.jsx
import { useState, useEffect } from 'react';
import './App.css';
import IDCardForm from './components/IDCardForm';
import IDCardPreview from './components/IDCardPreview';
import TemplateSelector from './components/TemplateSelector';
import IDCardHistory from './components/IDCardHistory';
import { saveCard, getCards } from './utils/storage';

// Define templates as constants
const TEMPLATES = {
  TEMPLATE_1: "template1",
  TEMPLATE_2: "template2"
};

const App = () => {
  const [studentData, setStudentData] = useState(null);
  const [selectedTemplate, setSelectedTemplate] = useState(TEMPLATES.TEMPLATE_1);
  const [savedCards, setSavedCards] = useState([]);

  useEffect(() => {
    loadSavedCards();
  }, []);

  const loadSavedCards = () => {
    const cards = getCards();
    setSavedCards(cards);
  };

  const handleFormSubmit = (data) => {
    setStudentData(data);
    // Removed toast
  };

  const handleTemplateSave = () => {
    if (!studentData) return;
    saveCard(studentData, selectedTemplate);
    loadSavedCards();
    // Removed toast
  };

  const handleLoadCard = (data, template) => {
    setStudentData(data);
    setSelectedTemplate(template);
    // Removed toast
  };

  return (
    <div className="app">
      <header className="app-header">
        <h1>Student ID Card Generator</h1>
      </header>

      <main className="app-main container">
        <div className="content-wrapper">
          <div className="form-section">
            <IDCardForm 
              onSubmit={handleFormSubmit} 
              initialData={studentData || undefined} 
            />
          </div>

          {studentData && (
            <div className="preview-section">
              <h2>Card Preview</h2>
              <TemplateSelector 
                selectedTemplate={selectedTemplate} 
                onTemplateChange={setSelectedTemplate} 
              />
              <IDCardPreview 
                studentData={studentData} 
                template={selectedTemplate}
                onSave={handleTemplateSave}
              />
            </div>
          )}
        </div>

        <IDCardHistory 
          cards={savedCards} 
          onLoadCard={handleLoadCard} 
          onRefresh={loadSavedCards} 
        />
      </main>
    </div>
  );
};

export default App;
