// src/utils/storage.js
const STORAGE_KEY = 'savedIDCards';

export const saveCard = (studentData, template) => {
  const savedCards = getCards();
  
  const newCard = {
    id: Date.now().toString(),
    date: new Date().toISOString(),
    studentData,
    template
  };
  
  savedCards.push(newCard);
  
  localStorage.setItem(STORAGE_KEY, JSON.stringify(savedCards));
  
  return newCard;
};

export const getCards = () => {
  const storedCards = localStorage.getItem(STORAGE_KEY);
  
  if (!storedCards) {
    return [];
  }
  
  try {
    return JSON.parse(storedCards);
  } catch (error) {
    console.error('Error parsing saved cards:', error);
    return [];
  }
};

export const deleteCard = (cardId) => {
  const savedCards = getCards();
  const updatedCards = savedCards.filter(card => card.id !== cardId);
  
  localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedCards));
  
  return updatedCards;
};
