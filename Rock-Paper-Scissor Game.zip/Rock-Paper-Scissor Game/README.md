# 🎮 Rock-Paper-Scissors Game

Welcome to my mini-game — a stylish and fun implementation of the classic **Rock-Paper-Scissors** game! 💥

## 🔗 Live Preview
(Coming soon — you can deploy using GitHub Pages!)

## 💡 Features
- Stylish neon UI with modern glassmorphism effects 💫
- Real-time score updates 🧠
- Reset button to replay easily 🔁
- Made using pure **HTML**, **CSS**, and **JavaScript**

## 🚧 Responsiveness Note
📱 Currently, this game works best on screens wider than `750px` but more improvements have been done   already to provide with the best UI for other media screen devices   
⚠️ Buttons and layout might overlap on smaller screens.  
🎯 I'm planning to improve the **responsiveness** using media queries very soon!

## 🛠️ Technologies Used
- HTML5
- CSS3 (with gradients, shadows, and media queries)
- JavaScript (DOM Manipulation + Game Logic)

## 👤 Author
**Sarad Agarwal**  
GitHub: [@Sarad-Agarwal](https://github.com/Sarad-Agarwal)

---

Feel free to ⭐ this repo if you liked the game!  
Pull requests to improve responsiveness or add features are welcome! 😊
