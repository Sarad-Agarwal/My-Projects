// Select the buttons
const rockBtn = document.querySelector('.rock-btn');
const scissorBtn = document.querySelector('.scissor-btn');
const paperBtn = document.querySelector('.paper-btn');
const resetBtn = document.querySelector(".reset")
const choices = {
    rock: {
        paper: "lose",
        rock: "draw",
        scissor: "win"
    },
    paper: {
        rock: "win",
        paper: "draw",
        scissor: "lose"
    },
    scissor: {
        paper: "win",
        rock: "lose",
        scissor: "draw"
    }
};

var user_score = 0;
var computer_score = 0;

// Function to handle the game logic
function generate(userChoice) {
    const arr = ["rock", "paper", "scissor"];
    const pos = Math.floor(Math.random() * 3);
    const computerChoice = arr[pos];

    // Update the displayed choices
    document.querySelector(".user-choices").textContent = `User Choice: ${userChoice}`;
    document.querySelector(".computer-choices").textContent = `Computer Choice: ${computerChoice}`;
    let result = choices[userChoice][computerChoice];
    document.querySelector(".result").textContent = `Result: ${result}`;


    if (result === "win")//i have won 
    {
        user_score = user_score + 1;
        document.querySelector(".user-users").textContent = `You: ${user_score}`;
    }
    if (result === "lose")//i have lose 
    {
        computer_score = computer_score + 1;
        document.querySelector(".computer-users").textContent = `Computer: ${computer_score}`;
    }



}

// Add event listeners to buttons
rockBtn.addEventListener('click', () => {
    generate("rock");
});
scissorBtn.addEventListener('click', () => {
    generate("scissor");
});
paperBtn.addEventListener('click', () => {
    generate("paper");
});

resetBtn.addEventListener('click', () => {
    location.reload();
})