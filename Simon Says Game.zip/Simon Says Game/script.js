let boxes = document.querySelectorAll(".box");
let level = 0;
let start = false; // indicating that game is not yet started
let h2 = document.querySelector("h2");
let userSeq = [];
let sysSeq = [];
let colors = ["yellow", "red", "green", "purple"];
let highestScore=0;
let hint = document.querySelector("#hint");

function sysFlash() {
    let id = Math.floor(Math.random() * 4);
    let color = colors[id];
    sysSeq.push(color);
    let randbtn;

    for (let box of boxes) {
        if (box.classList.contains(color)) {
            randbtn = box;
            break;
        }
    }
    if (randbtn) {
        setTimeout(() => {
            randbtn.classList.add("white");
            setTimeout(() => {
                randbtn.classList.remove("white");
            }, 500); // Increased Flash duration for better visibility
        }, 500);
    }
}

function userFlash(btn) {
    setTimeout(() => {
        btn.classList.add("white");
        setTimeout(() => {
            btn.classList.remove("white");
        }, 200);
    }, 50);
}

function levelUp() {
    level++;
    h2.innerText = `Level ${level}`;
    sysFlash();
}

document.addEventListener("keypress", () => {
    if (!start) {
        start = true;
        levelUp();
    }
});

function checkAns(id) {
    if (userSeq[id] === sysSeq[id]) {
        if (userSeq.length === sysSeq.length) {
            setTimeout(() => levelUp(), 1000); // FIXED: Delayed call
            userSeq = [];
        }
    } else {
        h2.innerText = "Game Over! Press any key to Start";
        hint.style.visibility="visible"
        document.querySelector("body").style.backgroundColor = "red";
        setTimeout(() => {
            document.querySelector("body").style.backgroundColor = "white";
        }, 150);
        setTimeout(reset, 2000);
    }
}

function btnPress() {
    let btn = this;
    userSeq.push(btn.getAttribute("id"));
    userFlash(btn);
    checkAns(userSeq.length - 1);
}

for (let btn of boxes) {
    btn.addEventListener("click", btnPress);
}

function reset() {
    console.log(sysSeq)
    h2.innerText = `Your Score is ${level}`;
    if(highestScore<level){
        highestScore=level;
    }
    setTimeout(() => {
        h2.innerHTML = `Press any key to Start<br><u>Highest Score is ${highestScore}</u>`;
        start = false;
        sysSeq = [];
        userSeq = [];
        level = 0;
    }, 2000); // Show the score for 2 seconds before resetting
}



hint.addEventListener("click", () => {
    // Hide the hint button
    hint.style.visibility = "hidden";

    // Create the <marquee> element
    let marq = document.createElement("marquee");
    marq.innerText = sysSeq; // Ensure sysSeq is defined

    // Set marquee properties
    marq.setAttribute("scrollamount", "20"); // Increase speed
    marq.setAttribute("loop", "1"); // Run only once
    marq.setAttribute("behavior", "scroll"); // Smooth scrolling

    // Append the <marquee> after 1 second
    setTimeout(() => {
        document.body.appendChild(marq);
    }, 1000);
});
